
/* an-ER-black-iris:e36bb5b4-a228-4ad2-8f04-9781fde295d5.js, VERSION: 5.0.0, Published: 2019/04/02 17:26:25 $*/
// GENERIC SOURCE TRACKER: an-ER-fade-in
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
	"id": "e36bb5b4-a228-4ad2-8f04-9781fde295d5",
	"name": "an-ER-black-iris",
	"description": "Black iris wipe into keyart scaling in and other endframe elements fading in",
	"type": "animations",
	"context": "Default",
	"state": "published",
	"updated": 1553801568961,
	"full_name": "NetflixDev/an-ER-black-iris",
	"html_url": "https://github.com/NetflixDev/an-ER-black-iris",
	"username": "GitHub",
	"version": "5.0.0",
	"minimum": "3.0.0"
}
